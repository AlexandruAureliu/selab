package ro.mta.se.tema;

/**
 * Clasa specializata in mentinerea variabilelor statice.
 *
 *
 * @author Alexandru Aureliu
 */

public class VariabileStatice
{
    public static int timpIntreSchimburi = 15;
}
