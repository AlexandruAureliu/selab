package ro.mta.se.tema;

/**
 * Clasa care implementeaza firma de transport
 * FirmaTransport este realizata dupa design pattern-ul singleton
 *
 * @author Alexandru Aureliu
 */

public class FirmaTransport
{
    private static FirmaTransport ourInstance = null;
    private String numeFirma;
    private int numarStatii;
    private Statie[] listaStatii;
    private RutePosibile rutePosibile;
    private Deplasari[] deplasari = new Deplasari[64];

    /**
     *
     * @param numeFirma_Param Nume Firma
     */
    public static FirmaTransport getInstance(String numeFirma_Param)
    {
        if (ourInstance == null)
        {
            ourInstance = new FirmaTransport(numeFirma_Param);
        }

        return ourInstance;
    }

    /**
     *
     * @param numeFirma_Param nume firma
     */
    private void setNumeFirma(String numeFirma_Param)
    {
        numeFirma = numeFirma_Param;
    }

    /**
     *
     * @return nume firma
     */
    private String getNumeFirma()
    {
        return numeFirma;
    }

    /**
     *
     * @param numarStatii_Param numarul de statii
     */
    public void setNumarStatii(int numarStatii_Param)
    {
        numarStatii = numarStatii_Param;

        listaStatii = new Statie[numarStatii];
    }

    /**
     *
     * @param listaStatii_Param lista cu statii
     */
    public void setListaStatii(String[] listaStatii_Param)
    {
        //System.out.println("Se initializeaza lista oraselor.");

        for(int i = 0; i < numarStatii; i++)
        {
            Statie statieNoua = new Statie(listaStatii_Param[i]);

            listaStatii[i] = statieNoua;
        }
    }

    /**
     *
     * @param rutePosibile_Param lista de adiacenta
     * @param numarStatii_Param numarul de statii
     * @param elementePrimaLinie_Param numele statilor
     */
    public void setRutePosibile(String[] rutePosibile_Param, int numarStatii_Param, String[] elementePrimaLinie_Param)
    {
        rutePosibile = new RutePosibile(rutePosibile_Param, numarStatii_Param, elementePrimaLinie_Param);
    }

    /**
     *
     * @param indexStatieSursa indexul statiei sursa
     * @param deplasari_Param indexul statiei destinatie
     */
    public void setDeplasari(int indexStatieSursa, String[] deplasari_Param)
    {
        int numarDeplasari = 0;
        String[] elementeDeplasari;

        for(int i = 0; i < deplasari_Param.length; i++)
        {
            elementeDeplasari = deplasari_Param[i].split(" ");

            deplasari[numarDeplasari] = new Deplasari(listaStatii[indexStatieSursa].getNumeStatie(), elementeDeplasari[0],
                    elementeDeplasari[1], elementeDeplasari[2]);

            numarDeplasari++;
        }
    }

    /**
     * Metoda apeleaza algoritmul de generare al rutelor
     * @param indiceStart_Param  indexul statiei sursa
     * @param indexFinal_Param indexul statiei destinatie
     */
    public void callForAfisareRute(int indiceStart_Param, int indexFinal_Param)
    {
        rutePosibile.afisareRute(indiceStart_Param, indexFinal_Param);
    }

    /**
     *
     * @param numeStatie_Param
     * @return
     */
    public int getIndexStatie(String numeStatie_Param)
    {
        int returnValue = 0;

        for(int i = 0; i < numarStatii; i++)
        {
            if(listaStatii[i].getNumeStatie().equals(numeStatie_Param))
            {
                returnValue = i;
            }
        }

        return returnValue;
    }

    /**
     * Constructor FirmaTransport
     * @param numeFirma_Param numele firmei
     */
    private FirmaTransport(String numeFirma_Param)
    {
        setNumeFirma(numeFirma_Param);

        //System.out.println("Se initializeaza Firma de Transport: " + getNumeFirma() +
        //        " ...\nFirma de Transport este initializata!\n");
    }
}