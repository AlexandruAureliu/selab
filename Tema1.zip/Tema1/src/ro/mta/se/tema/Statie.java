package ro.mta.se.tema;

/**
 * Clasa care cuprinde obiectele de tip Statie
 *
 * @author Alexandru Aureliu
 */

public class Statie
{
    private String numeStatie;

    /**
     *
     * @param numeStatie_Param Numele Statiei
     */
    private void setNumeStatie(String numeStatie_Param)
    {
        numeStatie = numeStatie_Param;
    }

    /**
     *
     * @return Numele Statiei
     */
    public String getNumeStatie()
    {
        return numeStatie;
    }

    /**
     * Constructorul pentr Statie
     * @param numeStatie_Param Numele Statiei
     */
    public Statie(String numeStatie_Param)
    {
        setNumeStatie(numeStatie_Param);

        //System.out.println("Statia: " + numeStatie + ".");
    }
}
