package ro.mta.se.tema;

import java.util.ArrayList;
import java.util.List;

/**
 * Clasa care se ocupa de controlul rutelor
 *
 * @author Alexandru Aureliu
 */

public class RutePosibile
{
    private String[] matriceDeAdiacenta;
    private ArrayList<Integer>[] listaAdiacenta;
    private int numarStatii;
    String[] listaStatie;

    /**
     *
     * @param matriceDeAdiacenta_Param lista de adiacenta
     */
    private void setMatriceDeAdiacenta(String[] matriceDeAdiacenta_Param)
    {
        matriceDeAdiacenta = matriceDeAdiacenta_Param;
    }

    /**
     *
     * @param numarStatii_Param numarul statiilo
     */
    private void setNumarStatii(int numarStatii_Param)
    {
        numarStatii = numarStatii_Param;
    }

    /**
     *
     * @param matriceDeAdiacenta_Param lista de adiacenta
     * @param numarStatii_Param numarul statiilor
     * @param elementePrimaLinie_Param lista cu numele statiilor
     */
    public RutePosibile(String[] matriceDeAdiacenta_Param, int numarStatii_Param, String[] elementePrimaLinie_Param)
    {
        setMatriceDeAdiacenta(matriceDeAdiacenta_Param);
        setNumarStatii(numarStatii_Param);

        listaStatie = elementePrimaLinie_Param;


        initializareListaAdiacenta();
    }

    private void initializareListaAdiacenta()
    {
        listaAdiacenta = new ArrayList[numarStatii];

        for(int i = 0; i < numarStatii; i++)
        {
            listaAdiacenta[i] = new ArrayList<>();
        }

        for(int i = 0; i < numarStatii; i++)
        {
            for(int j = 0; j < numarStatii; j++)
            {
                if(!matriceDeAdiacenta[i * numarStatii + j].equals("0"))
                {
                    listaAdiacenta[i].add(j);
                }
            }
        }
    }

    /**
     *
     * @param indiceStart indice statie start
     * @param indexFinal indice statie final
     */
    public void afisareRute(int indiceStart, int indexFinal)
    {
        boolean[] isVisited = new boolean[numarStatii];
        ArrayList<Integer> listaRute = new ArrayList<>();

        listaRute.add(indiceStart);

        afisareRuteRecursiv(indiceStart, indexFinal, isVisited, listaRute);
    }

    /**
     * Algoritmul de afisare al rutelor
     * @param indiceStart
     * @param indexFinal
     * @param isVisited variabila de tip boolean ce verifica daca un nod a fost sau nu vizitat
     * @param listaRuteLocala lista locala a nodurilor-statilor
     */
    private void afisareRuteRecursiv(Integer indiceStart, Integer indexFinal, boolean[] isVisited,
                                     List<Integer> listaRuteLocala)
    {
        isVisited[indiceStart] = true;
        String[][] replacements = new String[2][numarStatii];

        if (indiceStart.equals(indexFinal))
        {
            String listaRuteLocala_String = String.valueOf(listaRuteLocala);

            for(int i = 0; i < numarStatii; i++)
            {
                replacements[0][i] = Integer.toString(i);
                replacements[1][i] = listaStatie[i];
            }

            for(int i = 0; i < numarStatii; i++)
            {
                listaRuteLocala_String = listaRuteLocala_String.replace(replacements[0][i], replacements[1][i]);
            }

            System.out.println(listaRuteLocala_String);
        }

        for (Integer i : listaAdiacenta[indiceStart])
        {
            if (!isVisited[i])
            {
                listaRuteLocala.add(i);
                afisareRuteRecursiv(i, indexFinal, isVisited, listaRuteLocala);

                listaRuteLocala.remove(i);
            }
        }

        isVisited[indiceStart] = false;
    }

}
