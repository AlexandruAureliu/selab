package ro.mta.se.tema;

import Exceptii.BadRouteException;
import Exceptii.FisierInexistent;
import ro.mta.se.tema.Statie;

import java.io.IOException;
import java.util.Scanner;

/**
 * Clasa principala, ce contine metoda main();
 *
 *
 * @author Alexandru Aureliu
 */


public class Tema1
{
    /**
     * Metoda main();
     * Initializeaza myBufferReader si firmaDeTransport
     * Citeste de la tastatura numele statiei de plecare si numele statiei destinatie
     * Apeleaza algoritmul de determinare a rutei
     */

    public static void main(String args[]) throws IOException
    {
        try
        {
            Scanner keyboard = new Scanner(System.in);
            String numeStatieDePlecare;
            String numeStatieDestinatie;

            MyBufferReader myBufferReader = new MyBufferReader("inFile");

            if (myBufferReader == null)
            {
                throw new FisierInexistent();
            }

            FirmaTransport firmaDeTransport = FirmaTransport.getInstance("Apollo");

            myBufferReader.readFile(firmaDeTransport);

            System.out.println("Numele Statiei de Plecare: ");
            numeStatieDePlecare = keyboard.next();

            System.out.println("Numele Statiei Destinatie: ");
            numeStatieDestinatie = keyboard.next();

            if (numeStatieDePlecare.equals(numeStatieDestinatie))
            {
                throw new BadRouteException();
            }

            System.out.println("Oferta pentru " + numeStatieDePlecare + " - " + numeStatieDestinatie + ":");

            firmaDeTransport.callForAfisareRute(firmaDeTransport.getIndexStatie(numeStatieDePlecare),
                    firmaDeTransport.getIndexStatie(numeStatieDestinatie));

        }
        catch (BadRouteException exceptie_ruta)
        {
            exceptie_ruta.printError();
        }
        catch (FisierInexistent exceptie_fisier)
        {
            exceptie_fisier.printError();
        }
    }
}