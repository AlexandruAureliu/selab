package ro.mta.se.tema;

public class Deplasari
{
    private Statie statieSursa;
    private Statie statieDestinatie;
    private int timpPlecare;
    private int durataTransport;

    /**
     *
     * @param statieSursa_Param Numele Statiei Sursa
     */
    private void setStatieSursa(String statieSursa_Param)
    {
        statieSursa = new Statie(statieSursa_Param);
    }

    /**
     *
     * @return numele statiei sursa
     */
    public String getStatieSursa()
    {
        return statieSursa.getNumeStatie();
    }

    /**
     *
     * @param statieDestinatie_Param Numele Statiei Destinatie
     */
    private void setStatieDestinatie(String statieDestinatie_Param)
    {
        statieDestinatie = new Statie(statieDestinatie_Param);
    }

    /**
     *
     * @return numele statiei destinatie
     */
    public String getStatieDestinatie()
    {
        return statieDestinatie.getNumeStatie();
    }

    /**
     *
     * @param timpPlecare_Param ora la care se pleaca
     */
    private void setTimpPlecare(String timpPlecare_Param)
    {
        timpPlecare = Integer.parseInt(timpPlecare_Param);
    }

    /**
     *
     * @return timpul de plecare
     */
    public int getTimpPlecare()
    {
        return timpPlecare;
    }

    /**
     *
     * @param durataTransport_Param timpul in care se desfasoara transportul
     */
    private void setDurataTransport(String durataTransport_Param)
    {
        durataTransport = Integer.parseInt(durataTransport_Param);
    }


    /**
     *
     * @param sursa_Param statia sursa
     * @param destinatie_Param statia destinatie
     * @param timp_Param timpul la care se pleaca
     * @param durata_Param durata unui transport
     */
    public Deplasari(String sursa_Param, String destinatie_Param, String timp_Param, String durata_Param)
    {
        setStatieSursa(sursa_Param);
        setStatieDestinatie(destinatie_Param);
        setTimpPlecare(timp_Param);
        setDurataTransport(durata_Param);
    }
}
