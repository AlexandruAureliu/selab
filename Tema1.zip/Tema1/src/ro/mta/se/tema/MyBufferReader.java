package ro.mta.se.tema;

import Exceptii.EroareCitire;
import Exceptii.FisierInexistent;
import Exceptii.EroareNumarElementeListaAdiacenta;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Clasa specializata in citirea datelor din fisier;
 *
 *
 * @author Alexandru Aureliu
 */

public class MyBufferReader
{
    private String myFilename;
    private FileReader fileReader = null;
    private BufferedReader bufferedReader = null;

    private void setFilename(String myFilename_Param)
    {
        myFilename = myFilename_Param;
    }

    public String getFilename()
    {
        return myFilename;
    }


    /**
 * MyBufferReader class constructor
 * @param myFilename_Param Numele fisierului
 */

    public MyBufferReader(String myFilename_Param)
    {
        setFilename(myFilename_Param);

        //System.out.println("Se citesc datele din fisierul: " + getFilename() + " ...\n");
    }

    /**
     * @param firmaTransport_Param
     * @throws IOException
     */

    public void readFile(FirmaTransport firmaTransport_Param) throws IOException
    {
        try
        {
                FileReader fileReader = new FileReader("C:\\OneDrive\\IP\\Tema1\\src\\inFile");

                if (fileReader == null)
                {
                    throw new FisierInexistent();
                }

                BufferedReader bufferedReader = new BufferedReader(fileReader);
                String bufferLinie;
                String[] elementePrimaLinie, elementeADouaLinie, elementeDeplasari;
                int numarElementePrimaLinie, indexMax, indexsStatieSursa = 0;

                if (bufferedReader.ready())
                {
                    bufferLinie = bufferedReader.readLine();

                    elementePrimaLinie = bufferLinie.split(", ");
                    numarElementePrimaLinie = elementePrimaLinie.length;

                    if (numarElementePrimaLinie == 0)
                    {
                        throw new EroareCitire();
                    }

                    indexMax = numarElementePrimaLinie * numarElementePrimaLinie - 1;

                    firmaTransport_Param.setNumarStatii(numarElementePrimaLinie);
                    firmaTransport_Param.setListaStatii(elementePrimaLinie);

                    bufferLinie = bufferedReader.readLine();

                    elementeADouaLinie = bufferLinie.split(" ");
                    elementeADouaLinie[0] = elementeADouaLinie[0].replace("[", "");
                    elementeADouaLinie[indexMax] = elementeADouaLinie[indexMax].replace("]", "");

                    if (elementeADouaLinie.length != (numarElementePrimaLinie * numarElementePrimaLinie))
                    {
                        throw new EroareNumarElementeListaAdiacenta();
                    }

                    firmaTransport_Param.setRutePosibile(elementeADouaLinie, numarElementePrimaLinie,
                            elementePrimaLinie);

                    while ((bufferLinie = bufferedReader.readLine()) != null)
                    {
                        bufferLinie = bufferLinie.replaceAll("[\\[\\]]", "");

                        elementeDeplasari = bufferLinie.split(",");

                        firmaTransport_Param.setDeplasari(indexsStatieSursa, elementeDeplasari);

                        indexsStatieSursa++;
                    }
                }
        }
        catch (FisierInexistent exceptie_fisier)
        {
            exceptie_fisier.printError();
        }
        catch (EroareCitire exceptie_fisier)
        {
            exceptie_fisier.printError("Nu exista o lista cu numele statilor in fisier!");
        }
        catch (EroareNumarElementeListaAdiacenta exceptie)
        {
            exceptie.printError();
        }
    }
}
