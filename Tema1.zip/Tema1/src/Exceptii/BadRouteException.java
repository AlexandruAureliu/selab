package Exceptii;

public class BadRouteException extends Exception
{
    public void printError()
    {
        System.out.printf("Punctul de plecare este acelasi cu cel de sosire!\n");
    }
}
