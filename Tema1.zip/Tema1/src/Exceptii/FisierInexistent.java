package Exceptii;

public class FisierInexistent extends Exception
{
    public void printError()
    {
        System.out.printf("Fisierul pe care incercati sa il deschideti nu exista!\n");
    }
}
