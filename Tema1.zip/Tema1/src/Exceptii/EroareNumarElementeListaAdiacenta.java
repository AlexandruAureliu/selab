package Exceptii;

public class EroareNumarElementeListaAdiacenta extends Exception
{
    public void printError()
    {
        System.out.printf("Pentru n statii sunt necesare n^2 legaturi!\n");
    }
}
