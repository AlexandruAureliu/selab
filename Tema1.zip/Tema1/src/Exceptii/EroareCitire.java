package Exceptii;

public class EroareCitire extends Exception
{
    public void printError(String mesajEroare)
    {
        System.out.printf(mesajEroare + "\n");
    }
}
